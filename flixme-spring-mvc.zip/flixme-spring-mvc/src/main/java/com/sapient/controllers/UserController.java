package com.sapient.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sapient.dao.DaoException;
import com.sapient.dao.MovieDao;
import com.sapient.dao.ReviewDao;
import com.sapient.dao.UserDao;
import com.sapient.entity.Movie;
import com.sapient.entity.Review;
import com.sapient.entity.User;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class UserController {

	@Autowired
	UserDao dao;
	
	@Autowired
	MovieDao moviedao;
	
	@Autowired
	ReviewDao reviewdao;
	
	

	@RequestMapping(method = RequestMethod.GET, path = "/check-balance")
	public String getCustomerBalance( HttpSession session, Model model) throws DaoException {
		User user = (User) session.getAttribute("loggedInUser");
		if(user==null) {
			return "redirect:/login";
		}
		model.addAttribute("usr", user);
		return "check-balance";
	}
	@RequestMapping(method = RequestMethod.GET, path = "/search-movies")
	public String searchMovies( HttpSession session, Model model) throws DaoException {
		User user = (User) session.getAttribute("loggedInUser");
		if(user==null) {
			return "redirect:/login";
		}
		model.addAttribute("usr", user);
		return "search-movies";
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/edit-user")
	public String getUserFormToEdit(HttpSession session, Model model) throws DaoException
	{
		User user=(User)session.getAttribute("loggedInUser");
		if(user==null)
		{
			return "redirect:/login";
		}
		model.addAttribute("usr",dao.findById(user.getId()));

		return "edit-form";
	}
	@RequestMapping(path = "/reset-password", method = RequestMethod.GET)
	public String getResetPasswordForm(HttpSession session, Model model) throws DaoException {
		User user = (User) session.getAttribute("loggedInUser");
		if(user==null) {
			return "redirect:/login";
		}
		model.addAttribute("admin", user);
		return "reset-password";
	}
	
	@RequestMapping(path = "/reset-password", method = RequestMethod.POST)
	public String resetPassword(@RequestParam String password, HttpSession session, Model model) throws DaoException {
		User user = (User) session.getAttribute("loggedInUser");
		if(user==null) {
			return "redirect:/login";
		}
		user.setPassword(password);
		dao.updateUser(user);
		return "redirect:/";
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/add-review")
	public String getReviewForm(@RequestParam("id") Integer id, Model model, HttpSession session) throws DaoException
	{
		User user=(User) session.getAttribute("loggedInUser");
		if(user==null)
		{
			return "redirect:/login";
		}
		
		Review review=new Review();
		Movie movie=moviedao.findMovieById(id);
		review.setMovie(movie);
		review.setUser(user);
		model.addAttribute("review",review);
		return "add-review";
		
	}
	
	@RequestMapping(method=RequestMethod.POST, path="/add-review")
	public String handleReview(@ModelAttribute("review") Review review, HttpSession session)throws DaoException
	{
		User user=(User)session.getAttribute("loggedInUser");
		if(user==null)
		{
			return "redirect:/login";
		}
		try {
			review.setUser(user);
			
			reviewdao.addNewReview(review);
		}
		catch(Exception e)
		{
			log.debug("handling review",review);
		}
		return "redirect:/";
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST, path="/edit-user")
	public String updateUser(HttpSession session, @ModelAttribute User user) throws DaoException
	{
		dao.updateUser(user);
		session.setAttribute("loggedInUser", user);
		return "redirect:/user-details";
	}
	
	
	@RequestMapping(method=RequestMethod.GET, path="/search-by-title")
	public String getSearchByTitleForm(@RequestParam(required=false) String title, Model model) throws DaoException
	{
		if(title!=null)
		{
			model.addAttribute("movies",moviedao.getMoviesByTitle(title));
		}
		return "search-by-title-form";
	}
	@RequestMapping(method=RequestMethod.GET, path="/search-by-genre")
	public String getSearchByGenreForm(@RequestParam(required=false) String genre, Model model) throws DaoException
	{
		if(genre!=null)
		{
			model.addAttribute("movies",moviedao.getMoviesByGenre(genre));
		}
		return "search-by-genre-form";
	}
	@RequestMapping(method=RequestMethod.GET, path="/search-by-year")
	public String getSearchByYearForm(@RequestParam(required=false) String year, Model model) throws DaoException
	{
		if(year!=null)
		{
			model.addAttribute("movies",moviedao.getMoviesByReleaseYear(year));
		}
		return "search-by-year-form";
	}
	
	

	@RequestMapping(method = RequestMethod.GET, path = "/user-details")
	public String getCustomerById( HttpSession session, Model model) throws DaoException {
		User user = (User) session.getAttribute("loggedInUser");
		if(user==null) {
			return "redirect:/login";
		}
		model.addAttribute("usr", user);
		return "user-details";
	}
	@RequestMapping(method=RequestMethod.GET, path="/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/login")
	public String getLoginform()
	{
		return "login-form"; //will be resolved to/WEB-INF/pages/login-form.jsp
	}
	@RequestMapping(method=RequestMethod.POST, path="/login")
	
	public String handleLogin(@RequestParam String email, @RequestParam String password, HttpSession session, Model model)
	{
		try {
			User user=dao.findByEmail(email);
			if(user.getPassword().equals(password))
			{
				session.setAttribute("loggedInUser", user);
				return "redirect:/";
			}	
			model.addAttribute("errmsg", "Invalid username/password");
			return "login-form";
		} catch (DaoException e) {
			model.addAttribute("errmsg", "Invalid username/password");
			return "login-form";
		}
	}
	
	@RequestMapping(method=RequestMethod.GET, path="/register")
	
	public String getRegistrationform(Model model)
	{
		model.addAttribute("usr",new User());
		return "registration-form"; //will be resolved to/WEB-INF/pages/login-form.jsp
	}
	@RequestMapping(method=RequestMethod.POST, path="/register")
	public String handleRegister(@ModelAttribute("usr") User user, HttpSession session) throws DaoException
	{
		dao.addNewUser(user);
		session.setAttribute("loggedInUser", user);
		return "redirect:/";
	}
	@RequestMapping(path ="/show-review", method =RequestMethod.GET)
	public String showReviews(Model model,@RequestParam("id") Integer id) throws DaoException {
		model.addAttribute("reviews", reviewdao.getReviewByMovieId(id));
		return "show-reviews";
	}
}
