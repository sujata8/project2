package com.sapient.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.sapient.dao.MovieDao;
import com.sapient.entity.User;


import java.util.List;

import com.sapient.dao.DaoException;
import com.sapient.entity.Movie;

@Controller
public class MovieController {
	@Autowired
	private MovieDao moviedao;
	

	@RequestMapping(method = RequestMethod.GET, path = "/view-movies")
	public String getMovies(Model model) throws DaoException {
		List<Movie> movies = moviedao.findAll();
		model.addAttribute("movies", movies);
		return "view-movies";
	}

	@RequestMapping(method = RequestMethod.GET, path = "/add-movie")
	public String getMovieRegistration(Model model) {
		model.addAttribute("movie", new Movie());
		return "add-movie";
	}
	
	@RequestMapping("/get-movies")
	public String getMovieById(@RequestParam Integer id, Model model) throws DaoException {
		model.addAttribute("mo", moviedao.findMovieById(id));
		return "movie-details";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/add-movie")
	public String handleRegistration(@ModelAttribute("movie") Movie movie)
			throws DaoException {
		moviedao.addMovie(movie);
		return "redirect:/";
	}

	
}