package com.sapient.service;

import javax.security.sasl.SaslException;
import com.sapient.dao.UserDao;
import com.sapient.dao.DaoException;
import com.sapient.dao.DaoFactory;
import com.sapient.entity.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserService {

	private UserDao dao = DaoFactory.getUserDao();

	public void register(User customer) throws SaslException {
		try {
			dao.addNewUser(customer);
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}

	public User login(String email, String password) throws ServiceException {
		try {
			User c = dao.findByEmail(email);

			if (c == null) {
				throw new ServiceException("credentials cannot be left empty");
			}

			if (c.getPassword().equals(password)) {
				return c;
			} else {
				throw new ServiceException("Invalid email or password");
			}
		} catch (DaoException e) {
			log.warn("Exception while calling login", e);
			throw new ServiceException(e); // exception funneling
		}

	}

}