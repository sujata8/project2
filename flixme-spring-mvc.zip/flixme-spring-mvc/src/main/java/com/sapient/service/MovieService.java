package com.sapient.service;

import javax.security.sasl.SaslException;

import com.sapient.dao.DaoException;
import com.sapient.dao.DaoFactory;
import com.sapient.dao.MovieDao;
import com.sapient.entity.Movie;

public class MovieService {

	private MovieDao dao = DaoFactory.getMovieDao();

	public void addMovie(Movie movie) throws SaslException {
		try {
			dao.addMovie(movie);
		} catch (DaoException e) {
			e.printStackTrace();
		}

	}

}

//	private MovieDao dao = new MovieDaoHashMapImpl();
//
//	public void registerMovie(Movie movie) throws DaoException {
//		try {
//			dao.addMovie(movie);
//		} catch (DaoException e) {
//			throw new DaoException("Couldn't Register Movie " + e);
//		}
//
//	}
//
//	public List<Movie> getListOfAllMovies() throws DaoException {
//		List<Movie> list = new ArrayList<Movie>();
//		list = dao.getMovies();
//		return list;
//	}
//
//	public Movie getMovieById(int id) throws DaoException {
//		Movie movie = dao.getMovie(id);
//		return movie;
//	}
//
//	public void editMovie(Movie movie) throws DaoException {
//		try {
//			dao.updateMovie(movie);
//		} catch (DaoException e) {
//			throw new DaoException("Couldn't Edit Movie " + e);
//		}
//	}
//
//	public void deleteMovie(int id) throws DaoException {
//		try {
//			dao.deleteMovie(id);
//		} catch (DaoException e) {
//			throw new DaoException("Couldn't Delete Movie " + e);
//		}
//	}
