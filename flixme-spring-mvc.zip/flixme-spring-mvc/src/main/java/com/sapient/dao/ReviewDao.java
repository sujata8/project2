package com.sapient.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.sapient.entity.Review;

public interface ReviewDao {
	
	@Transactional(readOnly=false)
	public void addNewReview(Review review) throws DaoException;
	
	public Review findByReviewId(Integer id) throws DaoException;
	

	@Transactional(readOnly=false)
	public void updateReview(Review review)throws DaoException;
	
	public default List<Review>getReviewByUserId(Integer id)throws DaoException{
		throw new DaoException("Method not implemented yet");
	}
	public default List<Review>getReviewByMovieId(Integer id)throws DaoException{
		throw new DaoException("Method not implemented yet");
	}
	public default List<Review>getReviews()throws DaoException{
		throw new DaoException("Method not implemented yet");
	}
	

}
