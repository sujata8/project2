package com.sapient.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.sapient.entity.Movie;

@Repository
public class MovieDaoHibernateTemplateImpl implements MovieDao {

	@Autowired
	HibernateTemplate template;

	@Override
	public void addMovie(Movie movie) throws DaoException {

		try {
			template.persist(movie);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	@Override
	public Movie findMovieById(Integer id) throws DaoException {
		try {
			return template.get(Movie.class, id);
		} catch (Exception e) {
			throw new DaoException(e);
		}

	}
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public List<Movie> findAll() throws DaoException {
		try {
			String hql = "from Movie order by id";
			return (List<Movie>) template.find(hql);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<Movie> getMoviesByTitle(String title) throws DaoException {
		try {
			String hql="from Movie where title like ?0";
			title="%" + title + "%";
			return (List<Movie>)template.find(hql, title);
			
		}
		catch(DataAccessException e)
		{
			throw new DaoException(e);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<Movie> getMoviesByReleaseYear(String year) throws DaoException {
		try {
			String hql="from Movie where year like?0";
			return(List<Movie>)template.find(hql, year);
		}
		catch(DataAccessException e)
		{
			throw new DaoException(e);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<Movie> getMoviesByGenre(String genre) throws DaoException {
		try {
			String hql="from Movie where genre like ?0";
			genre="%"+genre+"%";
			return (List<Movie>)template.find(hql, genre);
		}
		catch(DataAccessException e)
		{
			throw new DaoException(e);
		}
	}

}
