package com.sapient.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.sapient.entity.User;

@Repository
public class UserDaoHibernateTemplateImpl implements UserDao {

	
	@Autowired
	HibernateTemplate template;
	
	@Override
	public void addNewUser(User user) throws DaoException {

		try {
			template.persist(user);
		}
		catch(Exception e)
		{
			throw new DaoException(e);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public User findById(Integer id) throws DaoException {
		try {
			return template.get(User.class, id);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	@Override
	public void updateUser(User user) throws DaoException {
		try {
			template.merge(user);
		} catch (DataAccessException e) {
			throw new DaoException(e);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public User findByEmail(String email) throws DaoException {
		try {
		String hql="from User where email=?0";
		return (User)template.find(hql,email).get(0);
		}
		catch(Exception e)
		{
			throw new DaoException(e);
		}
	}

	@Override
	public List<User> findAll() throws DaoException {
		return null;
	}

	@Override
	public List<User> findByCity(String city) throws DaoException {
		return null;
	}

}
