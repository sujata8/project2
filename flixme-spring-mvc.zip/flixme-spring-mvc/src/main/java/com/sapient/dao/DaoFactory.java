package com.sapient.dao;

public final class DaoFactory {
	private DaoFactory()
	{
		
	}
	
	public static UserDao getUserDao()
	{
		//use a discriminator to return required daoimpl
		return new UserDaoHibernateTemplateImpl();
	}

	public static MovieDao getMovieDao() {
		
		return new MovieDaoHibernateTemplateImpl();
	}
}