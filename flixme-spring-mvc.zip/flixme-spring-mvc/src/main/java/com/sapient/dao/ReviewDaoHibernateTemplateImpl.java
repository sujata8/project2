package com.sapient.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.sapient.entity.Review;
import com.sapient.entity.User;

@Repository
public class ReviewDaoHibernateTemplateImpl implements ReviewDao{

	@Autowired
	HibernateTemplate template;
	
	@Override
	public void addNewReview(Review review) throws DaoException {
		try {
			template.persist(review);
		}
		catch(Exception e)
		{
			throw new DaoException(e);
		}
	}

	@Override
	public Review findByReviewId(Integer id) throws DaoException {
		try {
			return template.get(Review.class, id);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	@Override
	public void updateReview(Review review) throws DaoException {
		try {
			template.merge(review);
		} catch (DataAccessException e) {
			throw new DaoException(e);
		}
		
	}
	
	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	public List<Review> getReviewByMovieId(Integer id) throws DaoException {
		try {
			String hql = "from Review where movie_id=?0";
			return (List<Review>) template.find(hql, id);
		}catch (DataAccessException e) {
			throw new DaoException(e);
		}
	}

}
