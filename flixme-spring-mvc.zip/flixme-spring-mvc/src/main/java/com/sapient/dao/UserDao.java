package com.sapient.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.sapient.entity.User;

public interface UserDao {
	// CRUD operations
	
	@Transactional(readOnly = false)
	public void addNewUser(User user) throws DaoException;

	public User findById(Integer id) throws DaoException;


	@Transactional(readOnly = false)
	public void updateUser(User user) throws DaoException;

	// Query

	public User findByEmail(String email) throws DaoException;

	public List<User> findAll() throws DaoException;

	public List<User> findByCity(String city) throws DaoException;

}