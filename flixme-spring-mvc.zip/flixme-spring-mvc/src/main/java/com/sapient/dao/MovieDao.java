package com.sapient.dao;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.sapient.entity.Movie;

public interface MovieDao {

	// CRUD operations
	@Transactional(readOnly = false)
	public void addMovie(Movie movie) throws DaoException;
	
	@Transactional(readOnly = false)
	public Movie findMovieById(Integer id) throws DaoException;

	public List<Movie> findAll() throws DaoException;
	
	public List<Movie> getMoviesByTitle(String title) throws DaoException;
	
	public List<Movie> getMoviesByReleaseYear(String year) throws DaoException;
	
	public List<Movie> getMoviesByGenre(String genre) throws DaoException;
	
}
